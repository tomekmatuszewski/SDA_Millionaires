from setuptools import find_packages, setup

setup(
    name='millionaires',
    version='0.1.0',
    author='Tm',
    author_email='tomasz_matuszewski@o2.pl',
    packages=find_packages(),
    include_package_data=True,
    description='Super Game'
)