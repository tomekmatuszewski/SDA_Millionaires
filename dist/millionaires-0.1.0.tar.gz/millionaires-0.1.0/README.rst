Millionaires Game!

After installing pack
from millionaires.game import Game
create instance of Game and try to get Million

If you want to add question to base:
log in as Admin
login : admin (env_variable login)
password: admin777 (env_variable password)

if you want to play log in as Player